



import java.util.ArrayList;

public class CafeUtil{


    public void militaryHoursTest(){

        for(int i = 0; i < 24; i++){ // Using int to declare what data type i will be
            System.out.println(i);
        }
    }

    public void coffeeNotification(){

        for(int i = 0; i < 24; i++){
            System.out.println(String.format("It's %s:00,  Do you need a coffee break?", (int) i));
        }
    }

    public void specialsAlert(){

        for(int i = 6; i < 16; i++){
            if(i % 3 == 0 ){
                System.out.println("Buy one get one free for the next 15 minutes!");
            }
            else{
                System.out.println("Stay tuned for deals announced throughout the day.");
            }
        }
    }

    public int leadsAtDay10(){
        int sum = 0;
        for( int i = 1; i <= 10; i++){
            sum += i;
        }
        return sum;
    }

    public void displayMenu(String[] menu){
        for(String item : menu){
            System.out.println(item);
        }
    }

    public double getOrderTotal( double[] items){
        
        float total = 0f;

        for(double item : items){
            total += (float)item;
        }
        return (double)total;
    }

    public double getHighestPrice( double[] items){
        double highest = 0;

        for(double item : items){

            if(highest < item){
                highest = (double) item;
            }
        }
        return (double) highest;


    }

    public ArrayList<String> raffleWinners(String[] customers){

        ArrayList<String> winners = new ArrayList<String>(); // Creating a NewArray variable 
        for( int i = 3; i < customers.length; i+=4){
                winners.add(customers[i]);
        }
        return winners;
    }
}